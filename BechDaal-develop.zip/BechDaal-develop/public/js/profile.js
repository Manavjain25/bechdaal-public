$(document).ready(function() {
  $("#addAdd").click(function() {
    $("#newAdd").slideToggle(300);
  });
});

function address(input){
  console.log('Hi')
}
