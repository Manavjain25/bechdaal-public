module.exports = {
  'url': process.env.mongo_url
};
